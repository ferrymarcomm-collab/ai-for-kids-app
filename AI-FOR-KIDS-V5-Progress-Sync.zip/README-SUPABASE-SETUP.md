# AI FOR KIDS — Supabase Setup

## 1. Environment variables
Create a `.env.local` file in the project root:

```env
VITE_SUPABASE_URL=https://YOUR_PROJECT_REF.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=sb_publishable_xxxxxxxxx
```

Use the **Project URL** and **Publishable key** from Supabase. Do not put a secret/service-role key in frontend code.

## 2. Authentication
Supabase Authentication should have:
- Allow new users to sign up: ON
- Allow anonymous sign-ins: OFF
- Email provider: Enabled
- Confirm email: OFF for the current development test

## 3. What this build does
- Adds email/password registration and login.
- Creates a profile automatically through the database trigger already installed.
- Keeps the existing free demo experience.
- Checks `subscriptions` for an authenticated user.
- Only a database row with `access_level = premium` and `status = active` unlocks premium in this build.
- Does not allow the browser to create premium subscriptions.

## 4. Important security rule
Never place a Supabase Secret/Service Role key in this Vite frontend. The browser should only receive the Publishable key. RLS remains the database security boundary.

## 5. Production payment
Payment activation should be done later by a backend/Edge Function or another trusted server process. Do not let the browser set its own subscription to premium.

## 6. V5 — Progress Sync

V5 adds authenticated progress synchronization for the `progress` table.

- When a logged-in student opens/completes a module, the module status is synced to Supabase.
- On login, existing server progress is loaded and merged with the local progress.
- The browser never receives a Secret/Service Role key.
- The existing `AI_FOR_KIDS_PROGRESS_V1` LocalStorage key is preserved as a local cache/fallback.

Before testing V5, run this once in Supabase SQL Editor:

```sql
create unique index if not exists progress_user_module_unique
on public.progress (user_id, module_id);
```

If the index already exists, the statement is harmless.
